""".. include:: ../README.md"""

from .client import Langshark  # noqa
from .version import __version__  # noqa
