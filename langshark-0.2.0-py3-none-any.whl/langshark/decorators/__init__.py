"""Integrate Langshark Tracing into your LLM applications with the Langshark Python SDK using the `@observe()` decorator.

*Simple example (decorator + openai integration)*

```python
from langshark.decorators import observe
from langshark.openai import openai # OpenAI integration

@observe()
def story():
    return openai.chat.completions.create(
        model="gpt-3.5-turbo",
        max_tokens=100,
        messages=[
          {"role": "system", "content": "You are a great storyteller."},
          {"role": "user", "content": "Once upon a time in a galaxy far, far away..."}
        ],
    ).choices[0].message.content

@observe()
def main():
    return story()

main()
```

See [docs](https://langshark.com/docs/sdk/python/decorators) for more information.
"""

from .langshark_decorator import langshark_context, observe, LangsharkDecorator

__all__ = ["langshark_context", "observe", "LangsharkDecorator"]
